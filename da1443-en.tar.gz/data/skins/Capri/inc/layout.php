<?php

function pagetit($pagetit, $tree) {
  global $tpl;
  return $tpl->pagetit($pagetit, $tree);
}

?>